<?php
require 'db.php';
$product_id='1';
$sql = "SELECT product_name,product_img,price FROM products WHERE product_id=:product_id";

try {
$db = getDB();
$stmt = $db->prepare($sql); 
$stmt->bindParam("product_id", $product_id);
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_OBJ);

$db = null;

foreach($products  as $row)
{ 
$product_name=$row->product_name;
$product_img=$row->product_img;
$price=$row->price;
}
} 
catch(PDOException $e) 
{	
echo 'Connection Error';
}
?>

<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="mobile-web-app-capable" content="yes">
    <title>Detect shake in phone using Jquery</title>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery.ios-shake.js"></script>
	<script type="text/javascript" src="js/jquery.ui.shake.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
		
		    
			setInterval(function(){ $('#shake').shake(); }, 3000);
			
            function phoneShake() {
            $('#shake').hide();
			var productID=$(".product_id").attr('id');
			var url='ajax_discount.php';
			var data='product_id='+productID;

			$.ajax({
			type:"POST",
			url:url,
			data:data,
			dataType:"json",
			success:function(data)
			{
			$('#shake').hide();
			
			$.each(data.product_discount, function(i,data)
			{
				
			var html="Price: <span id='cross'>"+data.price+"$</span> "+data.discount+"$ </br></br> <a href='#' class='button button-primary'>Buy Now</a>";
			$("#result").html(html);
			
			});
			

			}
			});
			
			  
            }

            $.shake({
               
                callback: function() {
                    phoneShake();
                }
            });
           
        
      
        });
    </script>
	<style>
	body{font-family:arial; }
	h1{font-size:15px}
	#main{text-align:center;font-size:16px;}
	#result{font-size:20px;font-weight:bold;margin:10px;color:#333333}
	
	#shake{text-align:center;width:200px;color:#00cc00;margin:0 auto;}
	#cross{text-decoration:line-through;color:#dedede}
	
	.button {
font-weight: bold;
padding: 12px 15px;
background: #3f8abf;
color: #fff !important;
font-size: 14px;
font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
cursor: pointer;
text-decoration: none;
text-shadow: 0 1px 0px rgba(0,0,0,0.15);
border-width: 1px 1px 3px !important;
border-style: solid;
border-color: #326e99;
white-space: nowrap;
overflow: hidden;
text-overflow: ellipsis;
display: -moz-inline-stack;
display: inline-block;
vertical-align: middle;
zoom: 1;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
-ms-border-radius: 5px;
-o-border-radius: 5px;
border-radius: 5px;
-webkit-box-sizing: border-box;
-moz-box-sizing: border-box;
box-sizing: border-box;
-webkit-box-shadow: 0 -1px 0 rgba(255,255,255,0.1) inset;
-moz-box-shadow: 0 -1px 0 rgba(255,255,255,0.1) inset;
box-shadow: 0 -1px 0 rgba(255,255,255,0.1) inset;
}

.button-primary {
background-color: #5fcf80 !important;
border-color: #3ac162 !important;
}
	</style>
</head>

<body>
<div id="main">
<h1>Shake your phone and get the discount.</h1>
<div id="<?php echo $product_id;?>" class="product_id">
<img src="<?php echo $product_img;?>" />
<h3><?php echo $product_name;?></h3>
</div>
<div id="result">Price: <?php echo $price;?>$</div>
<div id="shake">Just shake your phone</div>


</div>

    
    
</body>
</html>